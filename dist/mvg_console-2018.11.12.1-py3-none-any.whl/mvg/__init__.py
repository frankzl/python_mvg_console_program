__package_name__ = "mvg"
__version__ = "2018.11.12.1"
__description__ = "A Command Line Tool to get the MVG departures for a station."
